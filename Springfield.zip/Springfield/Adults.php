<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Springfield - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<style>
    body {
        font-family: 'Roboto', sans-serif;
        line-height: 1.6;
        color: #333;
        background: url('Images/bodybackground2.jpg') no-repeat center center/cover;
        margin: 0;
        padding: 0;
    }
    .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid #eb9b4b;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /*content section styles*/
            .header-section {
            position: relative;
            height: 70vh;
            background: url('images/bodybackground2.jpg') no-repeat center center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            }

            .content-overlay {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 40px 60px;
            border-radius: 10px;
            text-align: center;
            color: white;
            max-width: 70%;
            }

            .content-overlay h1 {
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #FF5733;
            }

            .content-overlay p {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 20px;
            }

           /* Content Section */
            .facts {
                max-width: 100%;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
                background-color: #2b221e;   
            }
            .facts h1{
                color: #e5e5e5;
                margin-bottom: 50px;
            }
            .facts-content {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 20px;
            }

            .image-container {
                flex: 1;
            }

            .image-container img {
                width: 90%;
            }

            .text-container {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                flex: 1;
            }

            .text-box {
                background-color: #9a9595;
                color: #333;
                padding: 20px;
                height: 200px;
                width: 300px;
                text-align: left;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            /* Hover Animation */
            .text-box:hover {
                transform: scale(1.05);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            }

            .text-box h3 {
                font-size: 1.2rem;
                margin-bottom: 10px;
            }

            .text-box p {
                font-size: 1rem;
            }
            /* Adoption journey section*/
            .pet-blog {
                display: flex;
                max-width: 90%;
                font-family: 'Montserrat', sans-serif;
                margin: 50px auto;
                background-color: #d3c4b6;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                transition: background-color 0.5s ease;
            }
            .pet-blog:hover {
                background-color: #c2b0a4;
            }

            .left-section {
                padding: 20px;
                color: #fff;
                background-color: rgba(255, 255, 255, 0.8);
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
                flex: 1;
                transition: background-color 0.5s ease;
            }

            .left-section h1 {
                font-size: 32px;
                margin-bottom: 20px;
                font-weight: 700;
                    color: #333;

            }

            .left-section p {
                font-size: 16px;
                margin-bottom: 20px;
                line-height: 1.5;
                color: #333;

            }
            .left-section a {
                color: #fefafa;
                font-size: 12px;
                text-decoration: none;
                display: inline-block;
                margin-bottom: 20px;
            }
            .right-section {
                flex: 0.7;
                padding-left: 20px;
                background: url('Images/inster2.png') no-repeat center center/cover;
            }  
           
            .adopt-now-btn {
                background-color: #b65353;
                color: #fff;
                padding: 15px 20px;
                text-decoration: none;
                font-size: 14px;
                border-radius: 5px;
                transition: background-color 0.3s, color 0.3s;
            }

            .adopt-now-btn:hover {
                background-color: #555;
                color: #fff;
            }
            /* Additional hover effect */
            .pet-blog:hover .left-content {
                background-color: #5a4d45;
            }

            .pet-blog:hover .image-container {
                background-color: #d0c4ba;
            } 
            .right-section img {
                max-width: 100%;
                height: auto;
                border-radius: 8px;
            }

            /* Bottom section */
            .bottom-section {
                display: flex;
                align-items: center;
                margin-top: 20px;
            }

            .icons {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 20px;
                padding: 20px;
                background-color: #e0e0e0;
                max-width: 90%;
                height: 200px;
                margin-left: 20px;
                flex-grow: 1;
                animation: fadeIn 1.5s ease-in-out;
            }

            .icon-item {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                padding: 10px;
                cursor: pointer;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .icon-item img {
                max-width: 90px;
                border-radius: 10px;
            }

            .icon-item p {
                font-size: 24px;
                color: #333;
                margin-top: 8px;
                text-align: center;
            }

            .icon-item:hover {
                animation: bounce 0.6s ease;
                transform: scale(1.1);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            @keyframes bounce {
                0%, 100% {
                    transform: translateY(0);
                }
                50% {
                    transform: translateY(-10px);
                }
            }        
             /*footer*/
        footer {
            text-align: center;
            padding: 20px 40px;
            background-color: #333;
            color: #FFFFFF;
            border-top: 4px solid #eb9b4b;
            
        }

        </style>
<body>
<?php if (isset($_GET['status']) && isset($_GET['message'])): ?>
        <script>
            alert("<?php echo $_GET['message']; ?>");
        </script>
    <?php endif; ?>
    <header>
    <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
    </div>
    <nav>
    	<ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="KIds.php">For Kids</a></li>
                <li><a href="Adults.php">For Adults</a></li>
                <li><a href="help.php">Help</a></li>
                <li><a href="dashboard.php">My Dashboard</a></li>
                <li><a href="edit_user.php">Edit Profile</a></li>
                <li>
                <?php
                
                if ($_SESSION['is_admin'] == 1){
                	echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                }?>
                </li>
                
              
        </ul>
        <div class="auth-buttons">
             	<a href="logout.php" class="btn">Logout</a>
        </div>
    </nav>
    </header>

    <!--content area-->
    <div class="header-section">
            <div class="content-overlay">
                <h1>Open Your Heart and Home</h1>
                <p>Adopting a pet is not just about bringing an animal into your home; it’s about making a lifelong commitment to a loving companion who will bring joy, laughter, and unconditional love into your life. Each year, countless animals find themselves in shelters, hoping for a second chance at happiness. By choosing to adopt, you’re not only giving a deserving pet a forever home but also gaining a loyal friend who will enrich your life in countless ways. </p>
                <p>Join us in making a difference—open your heart and start your journey with a new furry family member today!</p>
            </div>
        </div>

         <!--Adoption Journey Section-->
         <div class="pet-blog">
            <div class="left-section">
                <h1>Adoption Journey</h1>
                    <p>Bringing a pet into your home is more than just gaining a companion; it's about opening your heart to a lifetime of love and joy. By adopting, you're giving a deserving animal a second chance at happiness. With a little care, patience, and affection, you'll not only change their life, but they'll change yours too.</p>
                    <p><b>Start your journey of unconditional love today!</b></p>
                    <br>
                    <a href="#" class="adopt-now-btn">Adopt Now</a>
                
               <!-- Bottom Section-->
                 <div class="bottom-section">
                    <div class="icons">
                        <div class="icon-item">
                            <img src="Images/dogs.png" alt="Dog Icon">
                            <p>Dogs</p>
                        </div>
                        <div class="icon-item">
                            <img src="Images/cats.png" alt="Cat Icon">
                            <p>Cats</p>
                        </div>
                        <div class="icon-item" >
                            <img src="Images/bird.png" alt="Bird Icon">
                            <p>Birds</p>
                        </div>
                        <div class="icon-item" >
                            <img src="Images/rabbit.png" alt="Rabbit Icon">
                            <p>Rabbits</p>
                        </div>
                    </div>
                </div>
            </div>
            </div>

        <!--facts section-->
        <div class="facts">
            <h1>Owning a pet is great fun</h1>
            <div class="facts-content">
                <div class="image-container">
                    <img src="Images/petcat.jpg" alt="Woman with dog">
                </div>
                <div class="text-container">
                    <div class="text-box">
                        <h3>Companionship and Emotional Support</h3>
                        <p>Pets offer constant companionship, reducing loneliness and providing comfort, especially during tough times.</p>
                    </div>
                    <div class="text-box">
                        <h3>Physical Health Benefits</h3>
                        <p>Pets, especially dogs, encourage an active lifestyle, leading to better cardiovascular health, lower blood pressure, and reduced stress.</p>
                    </div>
                    <div class="text-box">
                        <h3>Mental Health Improvements</h3>
                        <p> Interacting with pets can boost mood, reduce anxiety and depression, and provide a sense of purpose through routine and responsibility.</p>
                    </div>
                    <div class="text-box">
                        <h3>Social Interaction and Community</h3>
                        <p>Pets help facilitate social interactions, creating opportunities to meet new people and fostering a sense of community.</p>
                    </div>
                </div>
            </div>           
        </div>
        <footer>
       <p>&copy;2021 Springfield Pet Rescue. All rights reserved.
       </footer>


</body>
</html>