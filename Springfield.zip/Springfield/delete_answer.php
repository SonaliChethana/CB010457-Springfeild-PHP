<?php
session_start();
if (!isset($_SESSION['user_name']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "pet_rescue");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_GET['id'])) {
    $answer_id = $_GET['id'];
    $connection->query("DELETE FROM questions WHERE id = $answer_id");
    header("Location: admin_dashboard.php?status=success&message=Question deleted successfully.");
    exit();
}

$connection->close();
?>
