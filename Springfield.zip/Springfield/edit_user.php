<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "pet_rescue");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$user_name = $_SESSION['user_name'];


$user_sql = "SELECT * FROM users WHERE user_name = ?";
$user_stmt = $connection->prepare($user_sql);
$user_stmt->bind_param("s", $user_name);
$user_stmt->execute();
$user_result = $user_stmt->get_result();

if ($user_result->num_rows === 0) {
    die("User not found.");
}

$user = $user_result->fetch_assoc();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    
    $update_sql = "UPDATE users SET full_name = ?, email = ? WHERE user_name = ?";
    $update_stmt = $connection->prepare($update_sql);
    $update_stmt->bind_param("sss", $full_name, $email, $user_name);

    if ($update_stmt->execute()) {
        
        if (!empty($new_password)) {
            $password_sql = "UPDATE users SET password = ? WHERE user_name = ?";
            $password_stmt = $connection->prepare($password_sql);
            $password_stmt->bind_param("ss", $new_password, $user_name);
            $password_stmt->execute();
        }

    
        header("Location: dashboard.php?status=success&message=Profile+was+updated+successfully!");
        exit();
	     
    } else {
        echo "Error updating user details: " . $connection->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Springfield - Edit Profile</title>
</head>
<style>
    body {
        font-family: 'Roboto', sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 0;
    }
    main {
        margin: 30px auto;
        background-color: #FFFFFF;
        padding: 40px;
        max-width: none;
        width: 50%; 
        border-radius: 15px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .title {
        font-size: 28px;
        color: #388E3C;
        margin-bottom: 30px;
        text-align: center;
    }

    .label {
        font-size: 16px;
        color: #616161;
        margin-bottom: 5px;
        display: block;
    }

    .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid #eb9b4b;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /*main*/        
        .input, input[type="text"], input[type="email"], input[type="password"], textarea, input[type="number"], input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #CCC;
            border-radius: 8px;
            font-size: 16px;
        }

        .input:focus, input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus, input[type="number"]:focus, textarea:focus {
            border-color: #4CAF50;
            outline: none;
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.3);
        }

        .button, input[type="submit"], button {
            background-color: #eb9b4b;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, box-shadow 0.3s;
            display: block;
            width: 100%;
        }

        .button:hover, input[type="submit"]:hover, button:hover {
            background-color: #FF5733;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }


        .popup-form {
            display: flex;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .popup-form .form-container {
            background-color: #FFFFFF;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            width: 100%;
        }

        .popup-form .form-group {
            margin-bottom: 20px;
        }


        .container {
            margin: 30px auto;
            background-color: #FFFFFF;
            padding: 40px;
            max-width: 800px; 
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            margin-bottom: 20px; 
        }

        .checkbox {
            margin-right: 10px; 
            transform: scale(1.5);
        }


        /*footer*/
        footer {
            text-align: center;
            padding: 20px 40px;
            background-color: #333;
            color: #FFFFFF;
            border-top: 4px solid #eb9b4b;
            
        }
        </style>
<body>
    <header>
    <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
    </div>
    <nav>
    	<ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="help.php">Help</a></li>
                <li><a href="dashboard.php">My Dashboard</a></li>
                <li><a href="edit_user.php">Edit Profile</a></li>
                <li>
                <?php
                
                if ($_SESSION['is_admin'] == 1){
                	echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                }?>
                </li>
                
              
        </ul>
        <div class="auth-buttons">
             	<a href="logout.php" class="btn">Logout</a>
        </div>
    </nav>
    </header>
    <main class="main-container">
    <h1 class="page-title">Edit Profile</h1>
    <form action="edit_user.php" method="POST" class="profile-form">
        <div class="form-group">
            <label for="full_name" class="form-label">Full Name</label>
            <input type="text" id="full_name" name="full_name" value="<?php echo $user['full_name']; ?>" required class="form-input">
        </div>
        <div class="form-group">
            <label for="email" class="form-label">Email</label>
            <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required class="form-input">
        </div>
        <div class="form-group">
            <label for="new_password" class="form-label">New Password (leave blank to keep current password)</label>
            <input type="password" id="new_password" name="new_password" class="form-input">
        </div>
        <div class="form-actions">
            <button type="submit" class="btn-primary">
                Update Profile
            </button>
        </div>
    </form>
</main>

  <footer>
  <p>&copy;2021 Springfield Pet Rescue. All rights reserved.
  </footer>
</body>
</html>

<?php
$user_stmt->close();
$connection->close();
?>
