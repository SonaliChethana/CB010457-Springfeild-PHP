<?php
session_start();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWS - Help </title>
    <link rel="stylesheet" type="text/css" href="css/header_footer.css">
    <link rel="stylesheet" type="text/css" href="css/info_pages.css">
</head>
<style>
      main{
        flex-grow:1;
        }


        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /*Container*/
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: url('images/paw.png') no-repeat center top / cover;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.6);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            background-color: #c96e0c;
        }

        .section {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .section:hover {
            transform: translateY(-10px);
        }

        /* Section Titles */
        .section h2 {
            color: #ff5733;
            font-size: 24px;
            margin-bottom: 15px;
            border-bottom: 2px solid #ffc787;
            padding-bottom: 10px;
        }

        /* List Styles */
        ul {
            list-style-type: square;
            margin-left: 20px;
        }

        /* Animation */
        .fade-in {
            animation: fadeInUp 0.6s ease-in-out both;
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Section Animations */
        .animated-section {
            opacity: 0;
            animation: fadeInSection 1s forwards;
        }

        @keyframes fadeInSection {
            0% {
                opacity: 0;
                transform: translateY(100px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
         /* Footer */
         footer {
            text-align: center;
            background-color: #eb9b4b;
            padding: 20px;
            color: #fff;
        }

        /* Button Styling */
        a.btn {
            text-decoration: none;
            color: #fff;
            background-color: #ffc787;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        a.btn:hover {
            background-color: #ffc787;
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .section {
                padding: 15px;
            }
        }

        </style>
<body>
    <header>
       <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
        </div>
        <nav>
            <ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="help.php">Help</a></li>
                <li>
                 <?php if (isset($_SESSION['user_name'])){ 
                 	echo '<a href="dashboard.php">My Dashboard</a>';
                 }?>	
                </li>
                <li>
                 <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
                    echo '<a href="admin_dashboard.php">Admin Dashboard</a>';
                 } ?>
                </li>
               
            </ul>
            <div class="auth-buttons">
                <?php if (isset($_SESSION['user_name'])): ?>
                    <a href="logout.php" class="btn">Logout</a>
                <?php else: ?>
                    <a href="register.php" class="btn">Register</a>
                    <a href="login.php" class="btn">Log In</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    <div class="container">
        <h1>Springfield Pet Rescue and Rehome Management System - Help Guide</h1>

        <div class="section">
            <h2>Overview</h2>
            <p>Welcome to the Springfield Pet Rescue, At Springfield Pet Rescue, we want to ensure a safe and loving environment for all our pets. Here are the steps how to use each feature of the system effectively.</p>
        </div>

        <div class="section">
            <h2>1. User Registration and Login</h2>
            <h4><strong>New User Registration:</strong></h4>
            <ul>
                <li>Click on the <strong>Register</strong> button on the top right corner of the homepage.</li>
                <li>Fill in the required fields. (i.e., Full Name, Username, Email, and Password)</li>
                <li>Make sure to use a secure password.</li>
                <li>Click <strong>Register</strong> to complete the registration process.</li>
                <li>If you are prompted with a message that the username or email is already taken, please redo the registration with an unique username and email. </li>
                <li>Now you'll be redirected to the login page.So you can use the previously created username and password to login.</li> 
            </ul>

            <h4><strong>Login:</strong></h4>
            <ul>
                <li>Click on the <strong>Login</strong> button the top right corner of the homepage.</li>
                <li>Enter your registered username and password.</li>
                <li>Click <strong>Login</strong>.</li>
            </ul>
        </div><hr>

       
        <div class="section">
            <h2>2. Dashboard</h2>
            <p>The dashboard provides an overview of key activities and actions you can take, such as managing pets and tracking adoptions</p>
            <p>At the top of the dashboard, you'll find each pet you've added displayed in individual boxes, showcasing their details.<p><br>
            <h4><strong>Adding a new pet:</strong></h4>
            <p>To add a new pet to the system.</p>
            <ul>
                <li>From the dashboard, click on <strong>Add New Pet</strong>located at the top right corner.</li>
                <li>Fill in the pet's details such as Name, Age, location, and description.</li>
                <li>Upload a picture of the pet.</li>
                <li>Click <strong>Add Pet</strong> to save the new entry.</li>
            </ul>
            <h4><strong>Edit the pet's information and Delete the pet:</strong></h4>
            <ul>
                <li> To edit pets details click the Edit button located in the bottom right corner of the pet's profile.</li>
                <li> To remove a pet from the dashboard, you can click the Delete button, also found in the bottom right corner of the pet's profile box.</li>
            </ul>
            <h4><strong>Adoption requests and confirmed adoption requests:</strong></h4>
                <ul>
                
                <li>When someone request to adopt a pet the requested person's details is shown in the bottom of the page. </li>
                <li>You can <strong>Confirm or Delete</strong> the the requested person's detais clicking the Confirm and Delete buttons.</li>
                <li>Confirmed adoption requests can also be seen in the bottom of the page and you can delete the confirmed adoption request after the pet is successfully adopted.</li>
             </ul>
        </div><hr>


        <div class="section">
            <h2>3. Home</h2>
            <p>This is the place you can see the pets information that other users uploaded.</p>
            <h4><strong>Adopt</strong></h4>
            <ul>
                <li>If you want to find a pet to adopt you can click the <strong>Adopt</strong> button under each pet.</li>
                <li>You can fill the Full name, city, District and the phone number and click Submit to send the adoption request.</li>
            </ul>
        </div>
        </div>
<footer>
        <p>&copy; 2024 PAWS. All Rights Reserved.</p>
</footer>   
</body>
</html>
