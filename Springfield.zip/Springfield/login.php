<?php
session_start();

if (isset($_SESSION['user_name'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Springfield - Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Montserrat', sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background: url('images/register2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #f5f5f5;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid #eb9b4b;  
        }
        nav {
            display: flex;
            align-items: center;
        }
        nav .menu {
            display: flex;
            list-style-type: none;
        }
        nav .menu li {
            margin-left: 20px;
        }
        nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        nav .menu li a:hover {
            color: #FF5733; 
        }
        nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }
        nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }
        nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        main {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background-color: rgba(0, 0, 0, 0.6);
            padding: 40px 30px;
            width: 35%;
            height: 500px;
            margin-left: 55%;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            text-align: center; /* Center text in the container */
        }
        .login-container p{
            margin-top: 10px;
        }
        h1 {
            margin-bottom: 20px;
        }
        .profile-photo {
            width: 80px; /* Adjust size as needed */
            height: auto; /* Maintain aspect ratio */
            border-radius: 50%;
            margin-bottom: 20px; /* Space below the profile photo */
        }
        input[type="text"], input[type="password"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px; 
            border:none; 
        }
        button {
           width:95%;
           padding :10px ; 
           background-color :#eb9b4b ; 
           margin-top :20px ;
           color :white ; 
           border-radius :5px ; 
           border :none ; 
       }
       button:hover {
           background-color :#FF5733 ; 
       }
       footer {
           text-align:center ;
           padding :20px ; 
           background-color :#eb9b4b ; 
       }
    </style>
</head>
<body>
    <?php if (isset($_GET['status']) && isset($_GET['message'])) : ?>
        <script>
           alert("<?php echo $_GET['message']; ?>");
        </script>
    <?php endif; ?>
    
    <header>
       <div class="logo">
           <a href="index.php"><img src="images/LogoNew2.png" alt="PAWS Logo"></a>
       </div>
       <nav>
           <ul class="menu">
               <li><a href="index.php">Home</a></li>
               <li><a href="about.php">About</a></li>
               <li><a href="WhatWeDo.php">What we do</a></li>
               <li><a href="help.php">Help</a></li>          
           </ul>
           <div class="auth-buttons">
               <a href="register.php" class="btn">Register</a>
           </div>
       </nav>
    </header>

    <main>
        <div class="login-container">
           <img src="images/user.jpg" alt="Profile Photo" class="profile-photo"> <!-- Add a profile photo -->
           <h1>Login to Your Account</h1>  
           <form action="login_process.php" method="POST">
               <input type="text" name="user_name" placeholder="Enter Username" required>
               <input type="password" name="password" placeholder="Enter Password" required>
               <button type="submit">Login</button>
               <p>If you don't have an account, <a href="register.php">Register here</a>.</p>
           </form>
       </div>
    </main>

    <footer>
       <p>&copy;2021 Springfield Pet Rescue. All rights reserved.</p>
    </footer>

</body>
</html>  