<?php
session_start();

// Establish the database connection
$connection = new mysqli("localhost", "root", "", "pet_rescue");

// Check for connection errors
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve form input data
    $full_name = $connection->real_escape_string($_POST['full_name']);
    $user_name = $connection->real_escape_string($_POST['user_name']);
    $email = $connection->real_escape_string($_POST['email']);
    $password = $_POST['password']; 

    // Hash the password securely using PASSWORD_DEFAULT (bcrypt by default)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    echo "Hashed password:". $hashed_password;

    // Prepare an SQL statement with placeholders
    $stmt = $connection->prepare("INSERT INTO users (full_name, user_name, email, password) VALUES (?, ?, ?, ?)");
    
    // Bind parameters to prevent SQL injection
    $stmt->bind_param("ssss", $full_name, $user_name, $email, $hashed_password);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        // Registration successful
        header("Location: register.php?status=success&message=Registration successful");
        exit();
    } else {
        // Log the error for troubleshooting and show user-friendly error message
        error_log("Error registering user: " . $stmt->error);
        header("Location: register.php?status=error&message=Error registering user");
        exit();
    }

    $stmt->close();
    $connection->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWS - Register</title>
    <link rel="stylesheet" type="text/css" href="css/header_footer.css">
</head>
<style>
    *{
        padding: 0;
        margin: 0;
        font-family: 'Roboto', sans-serif;
        
    }

    body {
        background: url("images/registration.jpg"); 
        background-size: cover;
        color:#ffffff;
        
    }
   
        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }



        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 40px;
            background-color: #eb9b4b; 
            color: #333; 
            border-bottom: 4px solid #eb9b4b;  
        }

        header .logo {
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav .menu {
            display: flex;
            list-style-type: none;
        }

        header nav .menu li {
            margin-left: 20px;
        }

        header nav .menu li a {
            color: #333; 
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        header nav .menu li a:hover {
            color: #FF5733; 
        }
        header nav .auth-buttons .menu{
            color: #FFFFFF; 
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            margin-left: 20px;
        }
        header nav .auth-buttons .menu:hover {
            color: #FF5733; 

        }
        header nav .auth-buttons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }


        header nav .auth-buttons .btn {
            color: #333; 
            text-decoration: none;
            background-color: #ffc787; 
            padding: 12px 25px;
            border-radius: 8px;
            margin-left: 15px;
            font-weight: 600;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        header nav .auth-buttons .btn:hover {
            background-color: #de7c0c;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

    .registration-form {
        margin-top:28px;
        position: absolute;
        top: 50%;
        Left: 30%;
        transform: translate(-50%, -50%);
        width: 25%;
        background: rgba(200, 218, 225, 0.7);
        padding: 30px;
        border-radius:20px;
        
    }

    .registration-form h1 {
        font-size: 30px;
        color: black;
        text-align: center;
        text-transform: uppercase;
        margin-bottom: 20px;
    }

    .registration-form p {
        font-size: 16px;
        margin: 10px 0;
    }

    .registration-form input {
        font-size: 16px;
        padding: 15px 10px;
        width: 90%;
        border: 0;
        border-radius: 5px;
        outline: none; 
    }


    .registration-form button {
        font-size: 18px;
        font-weight: bold;
        margin: 20px 0;
        padding: 10px 15px;
        width: 95%;
        border: 0;
        border-radius: 5px;
        background-color: #007bff; 
        color: #fff; 
        cursor: pointer;
        
        
    }

    .registration-form button:hover {
        background-color: #1071e7; 

    }
    /*Footer*/
    footer {
        text-align: center;
        padding: 20px 40px;
        background-color: #eb9b4b;
        color: #FFFFFF;
        border-top: 4px solid #eb9b4b;
    }


     
        </style>
<body>
     <?php if (isset($_GET['status']) && isset($_GET['message'])): ?>
        <script>
            alert("<?php echo $_GET['message']; ?>");
        </script>
    <?php endif; ?>
     <header>
       <div class="logo">
            <a href="index.php">
            	<img src="images/LogoNew2.png" alt="PAWS Logo">
            </a>
        </div>
        <nav>
            <ul class="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="WhatWeDo.php">What we do</a></li>
                <li><a href="help.php">Help</a></li>   
            </ul>
            <div class="auth-buttons">
                    <a href="login.php" class="btn">Log In</a>     
            </div>
        </nav>
    </header>
    
    <main>
    <div class="registration-form">
        <h1>Registration Form</h1>
        <form action="register_process.php" method="post">
            <p>Full Name:</p>
            <input type="text" name="full_name" placeholder="Full Name" required>
            
            <p>User Name:</p>
            <input type="text" name="user_name" placeholder="User Name" required>
            
            <p>Email:</p>
            <input type="email" name="email" placeholder="Email" required>
            
            <p>Password:</p>
            <input type="password" name="password" placeholder="Password" required>
            
            <button type="submit">Register</button>
        </form>
    </div>
   </main>
       <footer>
       <p>&copy;2021 Springfield Pet Rescue. All rights reserved.
       </footer>
</body>
</html>
